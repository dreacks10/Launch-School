names = ["Bob", "Joe", "Steve", "Mikayla", "Justin"]
x = 1

names.each do |name|
  puts "#{x}. #{name}"
  x += 1
end
