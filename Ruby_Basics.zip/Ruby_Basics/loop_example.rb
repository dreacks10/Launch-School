i = 0 
loop do 
  i = i + 1
  puts i
  break
end
