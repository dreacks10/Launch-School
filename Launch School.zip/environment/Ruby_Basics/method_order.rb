top

def top
  bottom
end

def bottom
  puts "reached the bottom"
end

