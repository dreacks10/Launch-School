puts ">> Type anything you want:"
text = gets
puts text