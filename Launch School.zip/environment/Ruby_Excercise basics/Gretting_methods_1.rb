def hello
 "Hello"
end

def world
 "World"
end

puts "#{hello} #{world}"