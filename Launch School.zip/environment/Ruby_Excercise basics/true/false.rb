boolean = [true, false].sample

puts (boolean ? "I'm true" : "I'm false")