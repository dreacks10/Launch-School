array1 = [1, 5, 9]
array2 = [1, 9, 5]

puts array1 == array2