def car(make, model)
  puts "#{make} #{model}"
end 

car('toyota', 'corolla')