puts "type anything you want:"
answer = gets.chomp.to_s
puts answer