puts "What is your age in years"
age = gets.chomp.to_i
puts "you are #{age * 12} months old."