def hello
  'Hello'
end

def world
  'World'
end

def greet
  "#{hello} #{world}"
  
end

puts greet