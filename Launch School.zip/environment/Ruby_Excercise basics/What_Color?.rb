colors = ['red', 'yellow', 'purple', 'green']

colors.each do |color|
    puts "I'm the color #{color}"
  end
  