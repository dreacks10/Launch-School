def print_me
  puts "I'm printing within the method!"
end